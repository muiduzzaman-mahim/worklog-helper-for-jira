/* Worklog Helper for Jira. Copyright (c) Muiduzzaman Mahim / Shadhin Tech. All rights reserved. */
chrome.runtime.onInstalled.addListener(function(){chrome.sidePanel&&chrome.sidePanel.setPanelBehavior&&chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(function(){})});
