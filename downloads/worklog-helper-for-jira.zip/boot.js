/* Worklog Helper for Jira. Copyright (c) Muiduzzaman Mahim / Shadhin Tech. All rights reserved. */
try{var __t=localStorage.getItem("dolphin-jira-theme");(__t==="light"||__t==="dark")&&document.documentElement.setAttribute("data-theme",__t)}catch{}
